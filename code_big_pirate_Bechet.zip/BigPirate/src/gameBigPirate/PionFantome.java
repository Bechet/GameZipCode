package gameBigPirate;
/**
 *<b> La classe PionFantome correspond au pion fantome gere par le systeme</b>
 *
 * @author Bechet, Di-Fant et Le Bellour
 *
 */
public class PionFantome extends Pion {

	/**
	 * <p>Constructeur avec en parametre la case ou positionner le pion</p>
	 * <p>@param _x : l'abscisse </p>
	 * <p>@param _y : l'ordonnee</p>
	 */
	public PionFantome(int _x, int _y){
		super(_x, _y);
	}
}
