package mouseMove;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class MouseMoveClass extends JPanel implements MouseMotionListener {
  private int mX, mY;
  private JLabel jX;
  private JLabel jY;

  public MouseMoveClass() {
	jX = new JLabel("0");
	jY = new JLabel("0");
	this.add(jX);
	this.add(jY);
    addMouseMotionListener(this);
    setVisible(true);
  }

  public void mouseMoved(MouseEvent me) {
    mX = (int) me.getPoint().getX();
    mY = (int) me.getPoint().getY();
    jX.setText(Integer.toString(mX));
    jY.setText(Integer.toString(mY));
  }

  public void mouseDragged(MouseEvent me) {
    mouseMoved(me);
  }

  public static void main(String[] args) {
    JFrame f = new JFrame();
    f.getContentPane().add(new MouseMoveClass());
    f.setSize(200, 200);
    f.setVisible(true);
  }

}