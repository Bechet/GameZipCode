package mouseClicked;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class MouseClick extends JPanel implements MouseMotionListener, MouseListener {
  private int mX, mY;
  private JLabel jX;
  private JLabel jY;

  public MouseClick() {
	jX = new JLabel("0");
	jY = new JLabel("0");
	this.add(jX);
	this.add(jY);
    addMouseMotionListener(this);
    setVisible(true);
  }
  

  public void mouseDragged(MouseEvent me) {
    miseAJour(me);
  }

  public void mouseClicked(MouseEvent me) {
	  miseAJour(me);
  }
  
  public void miseAJour(MouseEvent me)
  {
		mX = (int) me.getPoint().getX();
		mY = (int) me.getPoint().getY();
		jX.setText(Integer.toString(mX));
		jY.setText(Integer.toString(mY));
  }

/*
  public void paint(Graphics g) {
    g.setColor(Color.blue);
    g.fillRect(mX, mY, 5, 5);
  }
  */

  public static void main(String[] args) {
    JFrame f = new JFrame();
    f.getContentPane().add(new MouseClick());
    f.setSize(200, 200);
    f.setVisible(true);
  }

	
	@Override
	public void mouseMoved(MouseEvent e) {
		miseAJour(e);
		
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		miseAJour(e);
		
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		miseAJour(e);
		
	}


}